import dlt
from pyspark import pipelines as dp

@dlt.view(name="dimuser_source")
def get_dimuser_updates():
    df=spark.readStream.table("spotify_project.silver.dimuser")
    return df

dlt.create_streaming_table(name="dimuser")

dp.create_auto_cdc_flow(
  target = "dimuser",
  source = "dimuser_source",
  keys = ["user_id"],
  sequence_by = "updated_at",
  stored_as_scd_type = 2,
  name=None,
  once=False
)
