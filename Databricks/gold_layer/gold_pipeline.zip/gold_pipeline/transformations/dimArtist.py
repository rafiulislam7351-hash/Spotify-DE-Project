import dlt
from pyspark import pipelines as dp

@dlt.view(name="dimartist_source")
def get_dimartist_updates():
    df=spark.readStream.table("spotify_project.silver.dimartist")
    return df

dlt.create_streaming_table(name="dimartist")

dp.create_auto_cdc_flow(
  target = "dimartist",
  source = "dimartist_source",
  keys = ["artist_id"],
  sequence_by = "updated_at",
  stored_as_scd_type = 2,
  name=None,
  once=False
)
