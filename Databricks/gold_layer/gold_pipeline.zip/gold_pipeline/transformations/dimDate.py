import dlt
from pyspark import pipelines as dp

@dlt.view(name="dimdate_source")
def get_dimdate_updates():
    df=spark.readStream.table("spotify_project.silver.dimdate")
    return df

dlt.create_streaming_table(name="dimdate")

dp.create_auto_cdc_flow(
  target = "dimdate",
  source = "dimdate_source",
  keys = ["date_key"],
  sequence_by = "date",
  stored_as_scd_type = 2,
  name=None,
  once=False
)
