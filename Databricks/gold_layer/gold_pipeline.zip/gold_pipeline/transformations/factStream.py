import dlt
from pyspark import pipelines as dp

@dlt.view(name="factstream_source")
def get_factstream_updates():
    df=spark.readStream.table("spotify_project.silver.factstream")
    return df

dlt.create_streaming_table(name="factstream")

dp.create_auto_cdc_flow(
  target = "factstream",
  source = "factstream_source",
  keys = ["stream_id"],
  sequence_by = "stream_timestamp",
  stored_as_scd_type = 1,
  name=None,
  once=False
)
