import dlt
from pyspark import pipelines as dp

@dlt.view(name="dimtrack_source")
def get_dimtrack_updates():
    df=spark.readStream.table("spotify_project.silver.dimtrack")
    return df

dlt.create_streaming_table(name="dimtrack")

dp.create_auto_cdc_flow(
  target = "dimtrack",
  source = "dimtrack_source",
  keys = ["track_id"],
  sequence_by = "updated_at",
  stored_as_scd_type = 2,
  name=None,
  once=False
)
